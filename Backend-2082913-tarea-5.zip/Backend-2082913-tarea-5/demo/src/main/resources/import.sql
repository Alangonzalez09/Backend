INSERT INTO celulares(name, marca, created_at) VALUES ('Samsung', 'S21', NOW());
INSERT INTO celulares(name, marca, created_at) VALUES ('Samsung', 'S22', NOW());
INSERT INTO celulares(name, marca, created_at) VALUES ('Samsung', 'S22', NOW());
INSERT INTO celulares(name, marca, created_at) VALUES ('Apple', 'Iphone 14', NOW());
INSERT INTO celulares(name, marca, created_at) VALUES ('Apple', 'Iphone 15', NOW());
INSERT INTO celulares(name, marca, created_at) VALUES ('Xiaomi', 'Mi', NOW());