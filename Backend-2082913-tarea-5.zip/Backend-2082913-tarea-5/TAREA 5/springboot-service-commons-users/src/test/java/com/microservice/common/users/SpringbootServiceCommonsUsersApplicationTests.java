package com.microservice.common.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServiceCommonsUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
