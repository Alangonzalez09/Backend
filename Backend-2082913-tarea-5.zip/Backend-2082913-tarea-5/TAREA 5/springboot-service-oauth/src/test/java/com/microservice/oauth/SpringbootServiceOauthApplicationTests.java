package com.microservice.oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServiceOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
