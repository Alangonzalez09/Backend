
insert into usuarios (username, password, enabled, nombre, apellido, email) values ('username1', '12345', 1, 'Monica', 'yun', 'abcde@gmail.com');
insert into usuarios (username, password, enabled, nombre, apellido, email) values ('username2', 'password', 1, 'alexis', 'gutierrez', 'lalala@gmail.com');

INSERT INTO roles (name) VALUES ('ROLE_USER');
INSERT INTO roles (name) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_to_roles (user_id, rooles_id) VALUES (1, 1);
INSERT INTO usuarios_to_roles (user_id, rooles_id) VALUES (2, 2);
INSERT INTO usuarios_to_roles (user_id, rooles_id) VALUES (2, 1);


