package com.microservice.celular.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.microservice.celular.entity.Celular;
import com.microservice.celular.repository.CelularDao;


@Service
public class CelularServiceImpl implements CelularService{
	
	private CelularDao celularDao;
	public CelularServiceImpl(CelularDao celularDao) {
		this.celularDao = celularDao;
	}
	
	
	@Override
	public List<Celular> findAll() {
		return (List<Celular>) celularDao.findAll();
	}

	@Override
	public Celular findById(Long id) {
		return celularDao.findById(id).orElse(null);
	}

	@Override
	public void deleteById(Long id) {
		celularDao.deleteById(id);
	}

	@Override
	public Celular save(Celular instance) {
		return celularDao.save(instance);
	}

	@Override
	public boolean existsById(Long id) {
		return celularDao.existsById(id);
	}
}
