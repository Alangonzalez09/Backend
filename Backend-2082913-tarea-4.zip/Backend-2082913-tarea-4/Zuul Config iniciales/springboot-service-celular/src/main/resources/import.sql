
CREATE TABLE celulares (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    marca VARCHAR(255),
    create_at VARCHAR(255)
);
INSERT INTO celulares(name, marca, create_at) VALUES ('S21', 'Samsung', NOW());
INSERT INTO celulares(name, marca, create_at) VALUES ('S22', 'Samsung', NOW());
INSERT INTO celulares(name, marca, create_at) VALUES ('S23', 'Samsung', NOW());
INSERT INTO celulares(name, marca, create_at) VALUES ('Iphone 14', 'Apple', NOW());
INSERT INTO celulares(name, marca, create_at) VALUES ('Iphone 15', 'Apple', NOW());
INSERT INTO celulares(name, marca, create_at) VALUES ('Mi', 'Xiaomi', NOW());