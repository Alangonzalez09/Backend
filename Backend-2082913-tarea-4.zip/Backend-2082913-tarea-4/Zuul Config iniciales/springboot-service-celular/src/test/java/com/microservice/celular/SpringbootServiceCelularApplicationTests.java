package com.microservice.celular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServiceCelularApplicationTests {

	@Test
	void contextLoads() {
	}

}
