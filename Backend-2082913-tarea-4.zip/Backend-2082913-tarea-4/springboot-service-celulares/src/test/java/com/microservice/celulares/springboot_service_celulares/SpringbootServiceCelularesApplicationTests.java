package com.microservice.celulares.springboot_service_celulares;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServiceCelularesApplicationTests {

	@Test
	void contextLoads() {
	}

}
