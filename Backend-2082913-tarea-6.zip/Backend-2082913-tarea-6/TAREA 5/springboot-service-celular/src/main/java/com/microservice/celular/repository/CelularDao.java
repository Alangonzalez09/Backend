package com.microservice.celular.repository;

import org.springframework.data.repository.CrudRepository;

import com.microservice.celular.entity.Celular;

public interface CelularDao extends CrudRepository<Celular, Long>{

}
