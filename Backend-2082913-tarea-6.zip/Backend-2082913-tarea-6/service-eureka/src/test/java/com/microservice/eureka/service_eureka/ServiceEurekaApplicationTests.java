package com.microservice.eureka.service_eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
